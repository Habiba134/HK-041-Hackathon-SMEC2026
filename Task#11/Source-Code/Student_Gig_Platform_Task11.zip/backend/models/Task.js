
const mongoose = require('mongoose');
module.exports = mongoose.model('Task', new mongoose.Schema({
  title: String,
  description: String,
  budget: Number,
  deadline: String,
  status: { type: String, default: 'open' }
}));
