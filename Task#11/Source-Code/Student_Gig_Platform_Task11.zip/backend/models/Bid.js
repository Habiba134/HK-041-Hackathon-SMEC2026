
const mongoose = require('mongoose');
module.exports = mongoose.model('Bid', new mongoose.Schema({
  taskId: String,
  bidderId: String,
  price: Number,
  time: String
}));
