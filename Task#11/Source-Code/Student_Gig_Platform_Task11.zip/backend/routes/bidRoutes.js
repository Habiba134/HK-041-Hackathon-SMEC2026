
const router = require('express').Router();
const Bid = require('../models/Bid');

router.post('/place', async (req,res)=>{
  res.json(await new Bid(req.body).save());
});

router.get('/:taskId', async (req,res)=>{
  res.json(await Bid.find({taskId:req.params.taskId}));
});

module.exports = router;
