
const router = require('express').Router();
const User = require('../models/User');

router.post('/register', async (req,res)=>{
  await new User(req.body).save();
  res.send('Registered');
});

router.post('/login', async (req,res)=>{
  const user = await User.findOne(req.body);
  res.json(user);
});

module.exports = router;
