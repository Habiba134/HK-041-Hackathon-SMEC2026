
const router = require('express').Router();
const Task = require('../models/Task');

router.post('/create', async (req,res)=>{
  res.json(await new Task(req.body).save());
});

router.get('/all', async (req,res)=>{
  res.json(await Task.find());
});

module.exports = router;
