
export default function TaskBoard(){
  return <h2>Student Gig & Task Platform</h2>
}
