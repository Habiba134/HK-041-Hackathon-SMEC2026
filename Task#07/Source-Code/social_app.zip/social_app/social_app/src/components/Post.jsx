import React, { useState } from 'react';
import './Post.css';

const Post = ({ post }) => {
  const [liked, setLiked] = useState(false);
  const [likes, setLikes] = useState(post.likes);
  const [bookmarked, setBookmarked] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [comment, setComment] = useState('');
  const [comments, setComments] = useState(post.comments);

  const handleLike = () => {
    if (liked) {
      setLikes(likes - 1);
    } else {
      setLikes(likes + 1);
    }
    setLiked(!liked);
  };

  const handleBookmark = () => {
    setBookmarked(!bookmarked);
  };

  const addComment = (e) => {
    e.preventDefault();
    if (comment.trim()) {
      const newComment = {
        id: comments.length + 1,
        user: 'You',
        text: comment,
        time: 'Just now'
      };
      setComments([...comments, newComment]);
      setComment('');
    }
  };

  return (
    <div className="instagram-post">
      {/* Post Header */}
      <div className="post-header">
        <div className="user-info">
          <div className="user-avatar">
            <img src={post.userAvatar} alt={post.username} />
          </div>
          <div>
            <div className="username">{post.username}</div>
            <div className="location">{post.location}</div>
          </div>
        </div>
        <button className="more-options">⋯</button>
      </div>

      {/* Post Image */}
      <div className="post-image">
        <img src={post.image} alt="Post" />
      </div>

      {/* Post Actions */}
      <div className="post-actions">
        <div className="actions-left">
          <button 
            className={`action-btn ${liked ? 'liked' : ''}`}
            onClick={handleLike}
          >
            {liked ? '❤️' : '🤍'}
          </button>
          <button className="action-btn" onClick={() => setShowComments(!showComments)}>
            💬
          </button>
          <button className="action-btn">
            ↗️
          </button>
        </div>
        <button 
          className={`action-btn ${bookmarked ? 'bookmarked' : ''}`}
          onClick={handleBookmark}
        >
          {bookmarked ? '🔖' : '📑'}
        </button>
      </div>

      {/* Post Stats */}
      <div className="post-stats">
        <div className="likes-count">
          <span className="likes-icon">❤️</span>
          <strong>{likes.toLocaleString()} likes</strong>
        </div>
        <div className="post-caption">
          <strong>{post.username}</strong> {post.caption}
        </div>
        {post.tags.length > 0 && (
          <div className="post-tags">
            {post.tags.map(tag => (
              <span key={tag} className="tag">#{tag}</span>
            ))}
          </div>
        )}
        <div className="post-time">{post.timeAgo}</div>
      </div>

      {/* Comments Section */}
      {showComments && (
        <div className="comments-section">
          <div className="comments-list">
            {comments.map(comment => (
              <div key={comment.id} className="comment">
                <strong>{comment.user}</strong> {comment.text}
                <span className="comment-time">{comment.time}</span>
              </div>
            ))}
          </div>
          <form className="add-comment" onSubmit={addComment}>
            <input
              type="text"
              placeholder="Add a comment..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="comment-input"
            />
            <button 
              type="submit" 
              className={`comment-btn ${comment.trim() ? 'active' : ''}`}
            >
              Post
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

export default Post;