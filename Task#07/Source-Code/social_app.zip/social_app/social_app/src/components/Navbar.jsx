import React from 'react';
import { NavLink } from 'react-router-dom';
import './Navbar.css';

const Navbar = () => {
  return (
    <>
      {/* Top Navigation Bar */}
      <header className="navbar-top">
        <div className="navbar-container">
          {/* Logo */}
          <div className="navbar-logo">
            <NavLink to="/" className="logo-link">
              <span className="logo-text">Social App</span>
            </NavLink>
          </div>
          
          {/* Search Bar */}
          <div className="navbar-search">
            <input 
              type="text" 
              placeholder="Search"
              className="search-input"
            />
          </div>
          
          {/* Icons */}
          <div className="navbar-icons">
            <NavLink to="/" className={({ isActive }) => `nav-icon ${isActive ? 'active' : ''}`}>
              <span className="icon">🏠</span>
            </NavLink>
            <NavLink to="/create" className={({ isActive }) => `nav-icon ${isActive ? 'active' : ''}`}>
              <span className="icon">➕</span>
            </NavLink>
            <NavLink to="/profile" className={({ isActive }) => `nav-icon ${isActive ? 'active' : ''}`}>
              <span className="icon">👤</span>
            </NavLink>
          </div>
        </div>
      </header>

      {/* Bottom Navigation */}
      <nav className="navbar-bottom">
        <NavLink 
          to="/" 
          className={({ isActive }) => `bottom-nav-item ${isActive ? 'active' : ''}`}
        >
          <span className="nav-icon">🏠</span>
          <span className="nav-label">Home</span>
        </NavLink>
        
        <NavLink 
          to="/explore" 
          className={({ isActive }) => `bottom-nav-item ${isActive ? 'active' : ''}`}
        >
          <span className="nav-icon">🔍</span>
          <span className="nav-label">Search</span>
        </NavLink>
        
        <div className="bottom-nav-item add-post">
          <NavLink to="/create">
            <span className="nav-icon add-icon">+</span>
          </NavLink>
        </div>
        
        <NavLink 
          to="/reels" 
          className={({ isActive }) => `bottom-nav-item ${isActive ? 'active' : ''}`}
        >
          <span className="nav-icon">🎥</span>
          <span className="nav-label">Reels</span>
        </NavLink>
        
        <NavLink 
          to="/profile" 
          className={({ isActive }) => `bottom-nav-item ${isActive ? 'active' : ''}`}
        >
          <span className="nav-icon">👤</span>
          <span className="nav-label">Profile</span>
        </NavLink>
      </nav>
    </>
  );
};

export default Navbar;