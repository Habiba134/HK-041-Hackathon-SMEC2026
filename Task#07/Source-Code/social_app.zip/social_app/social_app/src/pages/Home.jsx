import React, { useState } from 'react';
import Post from '../components/Post';
import './Home.css';

const Home = () => {
  // Instagram-like posts with Unsplash images
  const [posts, setPosts] = useState([
    {
      id: 1,
      username: 'travelwanderer',
      userAvatar: 'https://images.unsplash.com/photo-1494790108755-2616b786d4d2?w=100&auto=format&fit=crop',
      location: 'Bali, Indonesia',
      image: 'https://images.unsplash.com/photo-1516483638261-f4dbaf036963?w=600&auto=format&fit=crop',
      likes: 12345,
      caption: 'Sunset dreams in Bali 🌅✨ The perfect end to an amazing day!',
      tags: ['travel', 'bali', 'sunset', 'paradise'],
      timeAgo: '2 HOURS AGO',
      comments: [
        { id: 1, user: 'beachlover', text: 'Stunning view! 😍', time: '2h' },
        { id: 2, user: 'wanderlust', text: 'Bucket list destination! ✈️', time: '1h' }
      ]
    },
    {
      id: 2,
      username: 'foodieforever',
      userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop',
      location: 'Tokyo, Japan',
      image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=600&auto=format&fit=crop',
      likes: 8765,
      caption: 'Authentic ramen experience in Tokyo! 🍜 Best bowl I\'ve ever had!',
      tags: ['food', 'ramen', 'tokyo', 'japanesefood'],
      timeAgo: '5 HOURS AGO',
      comments: [
        { id: 1, user: 'ramenlover', text: 'Which restaurant is this? 👀', time: '4h' },
        { id: 2, user: 'tokyotravel', text: 'That broth looks incredible!', time: '3h' }
      ]
    },
    {
      id: 3,
      username: 'fitnessjourney',
      userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop',
      location: 'Gym Life',
      image: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600&auto=format&fit=crop',
      likes: 34567,
      caption: 'Morning workout complete! 💪 Consistency is key to progress.',
      tags: ['fitness', 'workout', 'gym', 'motivation'],
      timeAgo: '1 DAY AGO',
      comments: [
        { id: 1, user: 'fitfam', text: 'Great motivation! 🔥', time: '22h' },
        { id: 2, user: 'gymrat', text: 'What\'s your routine?', time: '20h' }
      ]
    },
    {
      id: 4,
      username: 'urbandesigner',
      userAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&auto=format&fit=crop',
      location: 'New York City',
      image: 'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=600&auto=format&fit=crop',
      likes: 23456,
      caption: 'City lights and modern architecture ✨ Love this urban aesthetic!',
      tags: ['architecture', 'nyc', 'cityscape', 'design'],
      timeAgo: '2 DAYS AGO',
      comments: [
        { id: 1, user: 'cityexplorer', text: 'Amazing shot! 📸', time: '2d' },
        { id: 2, user: 'designlover', text: 'The symmetry is perfect!', time: '1d' }
      ]
    },
    {
      id: 5,
      username: 'naturephotographer',
      userAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&auto=format&fit=crop',
      location: 'Swiss Alps',
      image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&auto=format&fit=crop',
      likes: 45678,
      caption: 'Mountain therapy ⛰️ Nothing beats fresh alpine air!',
      tags: ['nature', 'mountains', 'alps', 'landscape'],
      timeAgo: '3 DAYS AGO',
      comments: [
        { id: 1, user: 'hikingaddict', text: 'Which trail is this? 🥾', time: '3d' },
        { id: 2, user: 'naturelover', text: 'Breathtaking view!', time: '2d' }
      ]
    }
  ]);

  const [stories] = useState([
    { id: 1, user: 'Your Story', avatar: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=100&auto=format&fit=crop', hasNew: true },
    { id: 2, user: 'travelwanderer', avatar: 'https://images.unsplash.com/photo-1494790108755-2616b786d4d2?w=100&auto=format&fit=crop' },
    { id: 3, user: 'foodieforever', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop' },
    { id: 4, user: 'fitnessjourney', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop' },
    { id: 5, user: 'urbandesigner', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&auto=format&fit=crop' },
    { id: 6, user: 'naturephotographer', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&auto=format&fit=crop' },
  ]);

  const [newPost, setNewPost] = useState('');

  const handleCreatePost = () => {
    if (newPost.trim()) {
      const post = {
        id: posts.length + 1,
        username: 'you',
        userAvatar: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=100&auto=format&fit=crop',
        location: 'Your Location',
        image: 'https://images.unsplash.com/photo-1579546929662-711aa81148cf?w=600&auto=format&fit=crop',
        likes: 0,
        caption: newPost,
        tags: ['newpost'],
        timeAgo: 'JUST NOW',
        comments: []
      };
      setPosts([post, ...posts]);
      setNewPost('');
    }
  };

  return (
    <div className="home-page">
      {/* Stories Section */}
      <div className="stories-container">
        <div className="stories-scroll">
          {stories.map(story => (
            <div key={story.id} className="story">
              <div className={`story-avatar ${story.hasNew ? 'has-new' : ''}`}>
                <img src={story.avatar} alt={story.user} />
              </div>
              <div className="story-username">{story.user}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Create Post Box */}
      <div className="create-post-box">
        <div className="create-post-header">
          <div className="user-avatar-small">
            <img src="https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=100&auto=format&fit=crop" alt="You" />
          </div>
          <input
            type="text"
            placeholder="What's on your mind?"
            value={newPost}
            onChange={(e) => setNewPost(e.target.value)}
            className="create-post-input"
          />
          <button 
            onClick={handleCreatePost}
            className="insta-btn"
            disabled={!newPost.trim()}
          >
            Post
          </button>
        </div>
      </div>

      {/* Posts Feed */}
      <div className="posts-feed">
        {posts.map(post => (
          <Post key={post.id} post={post} />
        ))}
      </div>
    </div>
  );
};

export default Home;