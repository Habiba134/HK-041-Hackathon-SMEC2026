import React, { useState } from 'react';

const Profile = () => {
  const [user, setUser] = useState({
    name: 'John Doe',
    bio: 'Hello! I love coding and building apps!',
    followers: 123,
    following: 45,
    posts: 12,
  });

  const [isEditing, setIsEditing] = useState(false);
  const [bio, setBio] = useState(user.bio);

  const handleFollow = () => {
    setUser({
      ...user,
      followers: user.followers + 1,
    });
  };

  const handleSaveBio = () => {
    setUser({ ...user, bio });
    setIsEditing(false);
  };

  return (
    <div>
      {/* Profile Header */}
      <div style={styles.profileHeader}>
        <div style={styles.avatarLarge}></div>
        <h2>{user.name}</h2>
        
        {isEditing ? (
          <div>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="input"
              rows="3"
            />
            <button onClick={handleSaveBio} className="btn primary-btn mt-10">
              Save Bio
            </button>
            <button 
              onClick={() => setIsEditing(false)} 
              className="btn mt-10"
              style={{ marginLeft: '10px' }}
            >
              Cancel
            </button>
          </div>
        ) : (
          <>
            <p>{user.bio}</p>
            <button 
              onClick={() => setIsEditing(true)}
              className="btn"
              style={{ marginTop: '10px' }}
            >
              Edit Profile
            </button>
          </>
        )}
      </div>

      {/* Stats */}
      <div style={styles.stats}>
        <div style={styles.statItem}>
          <strong>{user.posts}</strong>
          <div>Posts</div>
        </div>
        <div style={styles.statItem}>
          <strong>{user.followers}</strong>
          <div>Followers</div>
        </div>
        <div style={styles.statItem}>
          <strong>{user.following}</strong>
          <div>Following</div>
        </div>
      </div>

      {/* Follow Button */}
      <button 
        onClick={handleFollow}
        className="btn primary-btn"
        style={{ width: '100%', marginTop: '20px' }}
      >
        Follow
      </button>

      {/* User Posts */}
      <h3 style={{ marginTop: '30px' }}>Recent Posts</h3>
      <div className="post-card">
        <p>Just launched my new app! 🚀</p>
        <div className="post-actions">
          <button style={styles.likeButton}>❤️ 24</button>
          <button style={styles.commentButton}>💬 5</button>
        </div>
      </div>
    </div>
  );
};

const styles = {
  profileHeader: {
    textAlign: 'center',
    padding: '20px 0',
    borderBottom: '1px solid #ddd',
  },
  avatarLarge: {
    width: '100px',
    height: '100px',
    borderRadius: '50%',
    background: '#ccc',
    margin: '0 auto 15px',
  },
  stats: {
    display: 'flex',
    justifyContent: 'space-around',
    padding: '20px 0',
    borderBottom: '1px solid #ddd',
  },
  statItem: {
    textAlign: 'center',
  },
  likeButton: {
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    fontSize: '14px',
  },
  commentButton: {
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    fontSize: '14px',
  },
};

export default Profile;