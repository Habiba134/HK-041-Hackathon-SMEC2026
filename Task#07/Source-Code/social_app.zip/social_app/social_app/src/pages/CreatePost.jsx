import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const CreatePost = () => {
  const [content, setContent] = useState('');
  const [image, setImage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (content.trim()) {
      alert('Post created successfully!');
      navigate('/');
    }
  };

  return (
    <div>
      <h2>Create New Post</h2>
      <form onSubmit={handleSubmit}>
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="What's on your mind?"
          className="input"
          rows="5"
          required
        />
        
        <input
          type="text"
          value={image}
          onChange={(e) => setImage(e.target.value)}
          placeholder="Image URL (optional)"
          className="input"
        />
        
        {image && (
          <img 
            src={image} 
            alt="Preview" 
            style={styles.previewImage}
            onError={(e) => e.target.style.display = 'none'}
          />
        )}
        
        <div style={styles.buttonGroup}>
          <button 
            type="submit"
            className="btn primary-btn"
          >
            Post
          </button>
          <button 
            type="button"
            className="btn"
            onClick={() => navigate('/')}
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
};

const styles = {
  previewImage: {
    width: '100%',
    maxHeight: '300px',
    objectFit: 'cover',
    borderRadius: '10px',
    marginTop: '10px',
  },
  buttonGroup: {
    display: 'flex',
    gap: '10px',
    marginTop: '20px',
  },
};

export default CreatePost;