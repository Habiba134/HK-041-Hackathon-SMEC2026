const apiKey = "e6f9cdd1e1cafa56ffe82a25a74f9c44";

let map;
let marker;

function getAirQuality() {
    const city = document.getElementById("city").value;
    const output = document.getElementById("output");
    const loader = document.getElementById("loader");

    if (!city) {
        alert("Please enter a city name");
        return;
    }

    loader.style.display = "block";
    output.innerHTML = "";
    output.className = "result";

    fetch(`https://api.openweathermap.org/geo/1.0/direct?q=${city}&limit=1&appid=${apiKey}`)
        .then(res => {
            if (!res.ok) throw new Error("Geocoding failed");
            return res.json();
        })
        .then(data => {
            if (data.length === 0) throw new Error("City not found");

            const { lat, lon, name, country } = data[0];

            showMap(lat, lon, name, country);

            return fetch(`https://api.openweathermap.org/data/2.5/air_pollution?lat=${lat}&lon=${lon}&appid=${apiKey}`);
        })
        .then(res => {
            if (!res.ok) throw new Error("Air pollution fetch failed");
            return res.json();
        })
        .then(air => {
            loader.style.display = "none";

            const aqi = air.list[0].main.aqi;
            let quality, cls;

            if (aqi === 1) { quality = "Good"; cls = "good"; }
            else if (aqi === 2) { quality = "Fair"; cls = "fair"; }
            else if (aqi === 3) { quality = "Moderate"; cls = "moderate"; }
            else if (aqi === 4) { quality = "Poor"; cls = "poor"; }
            else { quality = "Very Poor"; cls = "very-poor"; }

            output.className = `result ${cls}`;
            output.innerHTML = `
                AQI: ${aqi}<br>
                Pollution Level: ${quality}
            `;
        })
        .catch(err => {
            loader.style.display = "none";
            output.innerHTML = "Error fetching data. Check API key or city name.";
            console.error(err);
        });
}

function showMap(lat, lon, city, country) {
    if (!map) {
        map = L.map("map").setView([lat, lon], 10);
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
            attribution: "© OpenStreetMap contributors"
        }).addTo(map);
    } else {
        map.setView([lat, lon], 10);
        if (marker) map.removeLayer(marker);
    }

    marker = L.marker([lat, lon]).addTo(map)
        .bindPopup(`<b>${city}, ${country}</b>`)
        .openPopup();
}
