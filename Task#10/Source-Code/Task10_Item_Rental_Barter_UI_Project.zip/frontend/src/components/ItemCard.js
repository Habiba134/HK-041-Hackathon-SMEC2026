
export default function ItemCard({item}){
  return (
    <div className='card'>
      <img src={item.img} width='100%' />
      <h3>{item.title}</h3>
      <p>{item.desc}</p>
      <button className='btn'>Rent / Barter</button>
    </div>
  );
}
