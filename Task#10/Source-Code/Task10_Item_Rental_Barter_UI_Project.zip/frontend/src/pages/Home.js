
import ItemCard from '../components/ItemCard';
export default function Home(){
  const items=[{title:'Camera',desc:'DSLR Camera',img:'https://via.placeholder.com/200'}];
  return (
    <div>
      <h2 style={{textAlign:'center'}}>Item Rental & Barter</h2>
      <div className='grid'>
        {items.map(i=><ItemCard item={i}/>)}
      </div>
    </div>
  );
}
