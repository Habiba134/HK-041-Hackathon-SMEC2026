
const mongoose = require('mongoose');
module.exports = mongoose.model('Item', new mongoose.Schema({
 title:String,
 description:String,
 image:String,
 rating:Number
}));
