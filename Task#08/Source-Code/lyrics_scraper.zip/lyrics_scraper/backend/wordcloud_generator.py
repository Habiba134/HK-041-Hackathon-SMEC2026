from wordcloud import WordCloud, STOPWORDS
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
import io
import base64
import re
from collections import Counter

class WordCloudGenerator:
    def __init__(self):
        # Extended stopwords for songs
        self.lyrics_stopwords = {
            'oh', 'yeah', 'hey', 'la', 'na', 'da', 'woah',
            'ooh', 'ah', 'uh', 'ha', 'ho', 'yo', 'ay', 'eh',
            'mm', 'mmm', 'hmm', 'woo', 'ya', 'yah', 'yea',
            'wooh', 'hah', 'heh', 'nah', 'huh'
        }
        
        self.all_stopwords = set(STOPWORDS).union(self.lyrics_stopwords)
    
    def generate_base64(self, text: str, options: dict = None) -> dict:
        """Generate word cloud and return as base64 image"""
        try:
            # Default options
            defaults = {
                'width': 800,
                'height': 500,
                'background_color': '#ffffff',
                'max_words': 150,
                'colormap': 'viridis',
                'contour_width': 0,
                'contour_color': 'steelblue',
                'prefer_horizontal': 0.9,
                'scale': 2,
                'min_font_size': 10,
                'max_font_size': 150
            }
            
            if options:
                defaults.update(options)
            
            # Generate word cloud
            wc = WordCloud(
                width=defaults['width'],
                height=defaults['height'],
                background_color=defaults['background_color'],
                max_words=defaults['max_words'],
                stopwords=self.all_stopwords,
                colormap=defaults['colormap'],
                contour_width=defaults['contour_width'],
                contour_color=defaults['contour_color'],
                prefer_horizontal=defaults['prefer_horizontal'],
                scale=defaults['scale'],
                min_font_size=defaults['min_font_size'],
                max_font_size=defaults['max_font_size'],
                collocations=False
            )
            
            wc.generate(text)
            
            # Convert to base64
            img_buffer = io.BytesIO()
            plt.figure(figsize=(12, 7))
            plt.imshow(wc, interpolation='bilinear')
            plt.axis('off')
            plt.tight_layout(pad=0)
            
            # Save to buffer
            plt.savefig(img_buffer, format='png', 
                       bbox_inches='tight', 
                       pad_inches=0,
                       dpi=100)
            plt.close()
            
            img_buffer.seek(0)
            img_base64 = base64.b64encode(img_buffer.read()).decode('utf-8')
            
            # Get word frequencies
            words = re.findall(r'\b[a-z]{3,}\b', text.lower())
            filtered_words = [w for w in words if w not in self.all_stopwords]
            word_counts = Counter(filtered_words)
            top_words = dict(word_counts.most_common(20))
            
            return {
                'success': True,
                'image': f"data:image/png;base64,{img_base64}",
                'top_words': top_words,
                'total_words': len(text.split()),
                'unique_words': len(set(filtered_words))
            }
            
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def get_available_colormaps(self):
        """Get list of available colormaps"""
        return [
            'viridis', 'plasma', 'inferno', 'magma', 'cividis',
            'spring', 'summer', 'autumn', 'winter', 'cool', 'hot',
            'copper', 'bone', 'gray', 'pink', 'Wistia',
            'tab10', 'tab20', 'Set2', 'Set3', 'rainbow'
        ]

if __name__ == "__main__":
    generator = WordCloudGenerator()
    sample_text = "hello world " * 50
    result = generator.generate_base64(sample_text)
    print(f"Success: {result['success']}")
    print(f"Image size: {len(result.get('image', ''))} chars")