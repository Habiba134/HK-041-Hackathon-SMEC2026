from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import os
import json
from datetime import datetime
from lyrics_scraper import LyricsScraper
from wordcloud_generator import WordCloudGenerator

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for frontend requests

# Initialize components
scraper = LyricsScraper()
generator = WordCloudGenerator()

# Create directories
os.makedirs('saved_wordclouds', exist_ok=True)
os.makedirs('history', exist_ok=True)

@app.route('/')
def home():
    return jsonify({
        'message': 'Lyrics Word Cloud API',
        'status': 'running',
        'endpoints': {
            '/api/lyrics': 'POST - Get lyrics for a song',
            '/api/wordcloud': 'POST - Generate word cloud',
            '/api/history': 'GET - Get search history',
            '/api/colormaps': 'GET - Get available colormaps'
        }
    })

@app.route('/api/lyrics', methods=['POST'])
def get_lyrics():
    """API endpoint to fetch lyrics"""
    try:
        data = request.json
        
        if not data or 'artist' not in data or 'song' not in data:
            return jsonify({'success': False, 'error': 'Missing artist or song'}), 400
        
        artist = data['artist'].strip()
        song = data['song'].strip()
        
        # Get lyrics
        result = scraper.get_lyrics(artist, song)
        
        # Save to history
        if result['success']:
            save_to_history(artist, song, result)
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/wordcloud', methods=['POST'])
def generate_wordcloud():
    """API endpoint to generate word cloud"""
    try:
        data = request.json
        
        if not data or 'text' not in data:
            return jsonify({'success': False, 'error': 'Missing text'}), 400
        
        text = data['text']
        options = data.get('options', {})
        
        # Generate word cloud
        result = generator.generate_base64(text, options)
        
        # Save image if requested
        if result['success'] and data.get('save', False):
            save_wordcloud_image(result['image'], data.get('filename', 'wordcloud'))
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/colormaps', methods=['GET'])
def get_colormaps():
    """Get available colormaps"""
    return jsonify({
        'success': True,
        'colormaps': generator.get_available_colormaps()
    })

@app.route('/api/history', methods=['GET'])
def get_history():
    """Get search history"""
    try:
        history_file = 'history/searches.json'
        if os.path.exists(history_file):
            with open(history_file, 'r') as f:
                history = json.load(f)
        else:
            history = []
        
        return jsonify({'success': True, 'history': history[-20:]})  # Last 20 searches
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

def save_to_history(artist, song, result):
    """Save search to history"""
    try:
        history_file = 'history/searches.json'
        history = []
        
        if os.path.exists(history_file):
            with open(history_file, 'r') as f:
                history = json.load(f)
        
        search_entry = {
            'artist': artist,
            'song': song,
            'timestamp': datetime.now().isoformat(),
            'word_count': result.get('word_count', 0),
            'success': result['success']
        }
        
        history.append(search_entry)
        
        # Keep only last 100 entries
        if len(history) > 100:
            history = history[-100:]
        
        with open(history_file, 'w') as f:
            json.dump(history, f, indent=2)
            
    except Exception as e:
        print(f"Error saving history: {e}")

def save_wordcloud_image(base64_image, filename):
    """Save word cloud image to file"""
    try:
        # Remove data:image/png;base64, prefix
        if ',' in base64_image:
            base64_image = base64_image.split(',')[1]
        
        # Decode and save
        image_data = base64.b64decode(base64_image)
        
        # Ensure filename is safe
        safe_filename = "".join(c for c in filename if c.isalnum() or c in (' ', '-', '_')).rstrip()
        safe_filename = safe_filename.replace(' ', '_')
        
        if not safe_filename:
            safe_filename = 'wordcloud'
        
        filepath = f"saved_wordclouds/{safe_filename}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        
        with open(filepath, 'wb') as f:
            f.write(image_data)
            
        return filepath
        
    except Exception as e:
        print(f"Error saving image: {e}")
        return None

if __name__ == '__main__':
    print("Starting Lyrics Word Cloud API...")
    print("Access the API at: http://localhost:5000")
    app.run(debug=True, port=5000)