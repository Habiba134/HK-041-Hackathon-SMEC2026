import requests
import re
import time

class LyricsScraper:
    def __init__(self):
        self.base_url = "https://api.lyrics.ovh/v1"
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
    
    def get_lyrics(self, artist: str, song: str) -> dict:
        """Fetch lyrics and return as dictionary"""
        try:
            # Format the request
            url = f"{self.base_url}/{artist}/{song}"
            
            response = requests.get(url, headers=self.headers, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if 'lyrics' in data:
                    lyrics = self._clean_lyrics(data['lyrics'])
                    return {
                        'success': True,
                        'lyrics': lyrics,
                        'word_count': len(lyrics.split()),
                        'artist': artist,
                        'song': song
                    }
            
            return {'success': False, 'error': 'Lyrics not found'}
            
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _clean_lyrics(self, lyrics: str) -> str:
        """Clean and format lyrics"""
        # Remove brackets and parentheses
        lyrics = re.sub(r'\[.*?\]', '', lyrics)
        lyrics = re.sub(r'\(.*?\)', '', lyrics)
        
        # Remove special characters but keep spaces
        lyrics = re.sub(r'[^\w\s]', ' ', lyrics)
        
        # Convert to lowercase and remove extra spaces
        lyrics = lyrics.lower().strip()
        lyrics = re.sub(r'\s+', ' ', lyrics)
        
        return lyrics

# Test
if __name__ == "__main__":
    scraper = LyricsScraper()
    result = scraper.get_lyrics("queen", "bohemian rhapsody")
    print(result)