// API Configuration
const API_BASE_URL = 'http://localhost:5000';

// DOM Elements
const artistInput = document.getElementById('artist');
const songInput = document.getElementById('song');
const searchBtn = document.getElementById('searchBtn');
const loading = document.getElementById('loading');
const resultContainer = document.getElementById('resultContainer');
const topWordsContainer = document.getElementById('topWords');
const saveBtn = document.getElementById('saveBtn');
const refreshBtn = document.getElementById('refreshBtn');
const randomBtn = document.getElementById('randomBtn');
const fullscreenBtn = document.getElementById('fullscreenBtn');
const closeModal = document.getElementById('closeModal');
const fullscreenModal = document.getElementById('fullscreenModal');
const fullscreenImage = document.getElementById('fullscreenImage');
const historyList = document.getElementById('historyList');

// Word cloud settings
const maxWordsSlider = document.getElementById('maxWords');
const maxWordsValue = document.getElementById('maxWordsValue');
const colormapSelect = document.getElementById('colormap');
const bgColorSelect = document.getElementById('bgColor');

// Song info elements
const infoArtist = document.getElementById('infoArtist');
const infoSong = document.getElementById('infoSong');
const infoTotalWords = document.getElementById('infoTotalWords');
const infoUniqueWords = document.getElementById('infoUniqueWords');
const infoStatus = document.getElementById('infoStatus');

// Example songs
const exampleSongs = [
    { artist: 'Queen', song: 'Bohemian Rhapsody' },
    { artist: 'Taylor Swift', song: 'Blank Space' },
    { artist: 'The Beatles', song: 'Hey Jude' },
    { artist: 'Ed Sheeran', song: 'Shape of You' },
    { artist: 'Adele', song: 'Hello' },
    { artist: 'Michael Jackson', song: 'Billie Jean' },
    { artist: 'Whitney Houston', song: 'I Will Always Love You' },
    { artist: 'Eminem', song: 'Lose Yourself' },
    { artist: 'Coldplay', song: 'Viva La Vida' },
    { artist: 'Bruno Mars', song: 'Uptown Funk' }
];

// Current state
let currentLyrics = '';
let currentWordCloud = null;
let currentArtist = '';
let currentSong = '';

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    // Load colormaps from API
    loadColormaps();
    
    // Load search history
    loadHistory();
    
    // Set up example song click handlers
    setupExampleSongs();
});

// Update slider value display
maxWordsSlider.addEventListener('input', () => {
    maxWordsValue.textContent = maxWordsSlider.value;
});

// Search for lyrics and generate word cloud
searchBtn.addEventListener('click', async () => {
    const artist = artistInput.value.trim();
    const song = songInput.value.trim();
    
    if (!artist || !song) {
        showError('Please enter both artist and song title');
        return;
    }
    
    await searchAndGenerate(artist, song);
});

// Save current word cloud
saveBtn.addEventListener('click', () => {
    if (!currentWordCloud) {
        showError('No word cloud to save');
        return;
    }
    
    saveWordCloud();
});

// Regenerate word cloud with current lyrics
refreshBtn.addEventListener('click', () => {
    if (!currentLyrics) {
        showError('No lyrics available to regenerate');
        return;
    }
    
    generateWordCloudFromLyrics(currentLyrics);
});

// Random song button
randomBtn.addEventListener('click', () => {
    const randomSong = exampleSongs[Math.floor(Math.random() * exampleSongs.length)];
    artistInput.value = randomSong.artist;
    songInput.value = randomSong.song;
    
    // Auto-search
    searchAndGenerate(randomSong.artist, randomSong.song);
});

// Fullscreen view
fullscreenBtn.addEventListener('click', () => {
    if (!currentWordCloud) {
        showError('No word cloud to display');
        return;
    }
    
    const wordcloudImg = document.getElementById('wordcloudImage');
    if (wordcloudImg) {
        fullscreenImage.src = wordcloudImg.src;
        fullscreenModal.style.display = 'flex';
    }
});

// Close fullscreen modal
closeModal.addEventListener('click', () => {
    fullscreenModal.style.display = 'none';
});

// Close modal on background click
fullscreenModal.addEventListener('click', (e) => {
    if (e.target === fullscreenModal) {
        fullscreenModal.style.display = 'none';
    }
});

// Main function to search and generate
async function searchAndGenerate(artist, song) {
    try {
        showLoading(true);
        updateStatus('Searching for lyrics...');
        
        // Step 1: Get lyrics
        const lyricsResult = await getLyrics(artist, song);
        
        if (!lyricsResult.success) {
            showError(lyricsResult.error || 'Failed to fetch lyrics');
            showLoading(false);
            return;
        }
        
        currentLyrics = lyricsResult.lyrics;
        currentArtist = artist;
        currentSong = song;
        
        // Update song info
        updateSongInfo(artist, song, lyricsResult);
        
        // Step 2: Generate word cloud
        await generateWordCloudFromLyrics(currentLyrics);
        
        showLoading(false);
        updateStatus('Word cloud generated successfully');
        
    } catch (error) {
        showError('An error occurred: ' + error.message);
        showLoading(false);
        updateStatus('Error occurred');
    }
}

// API: Get lyrics
async function getLyrics(artist, song) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/lyrics`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ artist, song })
        });
        
        return await response.json();
    } catch (error) {
        return { success: false, error: 'Network error. Make sure backend is running.' };
    }
}

// Generate word cloud from lyrics
async function generateWordCloudFromLyrics(lyrics) {
    try {
        updateStatus('Generating word cloud...');
        
        const options = {
            max_words: parseInt(maxWordsSlider.value),
            colormap: colormapSelect.value,
            background_color: bgColorSelect.value,
            width: 1000,
            height: 600
        };
        
        const response = await fetch(`${API_BASE_URL}/api/wordcloud`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ 
                text: lyrics, 
                options: options,
                save: false 
            })
        });
        
        const result = await response.json();
        
        if (!result.success) {
            throw new Error(result.error);
        }
        
        currentWordCloud = result;
        
        // Display word cloud
        displayWordCloud(result.image);
        
        // Display top words
        displayTopWords(result.top_words);
        
        // Update word counts
        infoUniqueWords.textContent = result.unique_words || '0';
        
        updateStatus('Word cloud ready');
        
    } catch (error) {
        showError('Failed to generate word cloud: ' + error.message);
        updateStatus('Generation failed');
    }
}

// Display word cloud image
function displayWordCloud(imageData) {
    resultContainer.innerHTML = `
        <img id="wordcloudImage" src="${imageData}" 
             alt="Word Cloud" class="fade-in">
    `;
    
    // Add click to view fullscreen
    const img = document.getElementById('wordcloudImage');
    img.addEventListener('click', () => {
        fullscreenImage.src = img.src;
        fullscreenModal.style.display = 'flex';
    });
}

// Display top words list
function displayTopWords(topWords) {
    if (!topWords || Object.keys(topWords).length === 0) {
        topWordsContainer.innerHTML = '<p class="placeholder">No words to display</p>';
        return;
    }
    
    let html = '';
    Object.entries(topWords).forEach(([word, count], index) => {
        const size = Math.max(16, 24 - index * 0.5); // Decreasing font size
        html += `
            <div class="word-item fade-in" style="animation-delay: ${index * 0.05}s">
                <span class="word-text" style="font-size: ${size}px">${word}</span>
                <span class="word-count">${count}</span>
            </div>
        `;
    });
    
    topWordsContainer.innerHTML = html;
}

// Update song information
function updateSongInfo(artist, song, lyricsResult) {
    infoArtist.textContent = artist;
    infoSong.textContent = song;
    infoTotalWords.textContent = lyricsResult.word_count || '0';
    infoStatus.textContent = 'Lyrics found';
}

// Update status message
function updateStatus(message) {
    infoStatus.textContent = message;
}

// Save word cloud to file
function saveWordCloud() {
    if (!currentWordCloud || !currentWordCloud.image) {
        showError('No word cloud to save');
        return;
    }
    
    try {
        // Create a link element
        const link = document.createElement('a');
        link.href = currentWordCloud.image;
        link.download = `${currentArtist}_${currentSong}_wordcloud.png`.replace(/[^a-z0-9]/gi, '_').toLowerCase();
        link.click();
        
        showNotification('Word cloud saved successfully!');
        
    } catch (error) {
        showError('Failed to save word cloud');
    }
}

// Load colormaps from API
async function loadColormaps() {
    try {
        const response = await fetch(`${API_BASE_URL}/api/colormaps`);
        const data = await response.json();
        
        if (data.success && data.colormaps) {
            // Update select options
            colormapSelect.innerHTML = '';
            data.colormaps.forEach(colormap => {
                const option = document.createElement('option');
                option.value = colormap;
                option.textContent = colormap.charAt(0).toUpperCase() + colormap.slice(1);
                colormapSelect.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Failed to load colormaps:', error);
    }
}

// Load search history
async function loadHistory() {
    try {
        const response = await fetch(`${API_BASE_URL}/api/history`);
        const data = await response.json();
        
        if (data.success && data.history) {
            displayHistory(data.history);
        } else {
            historyList.innerHTML = '<p>No search history yet</p>';
        }
    } catch (error) {
        historyList.innerHTML = '<p>Failed to load history</p>';
    }
}

// Display history
function displayHistory(history) {
    if (!history || history.length === 0) {
        historyList.innerHTML = '<p>No search history yet</p>';
        return;
    }
    
    // Reverse to show newest first
    const reversedHistory = [...history].reverse();
    
    let html = '';
    reversedHistory.forEach(item => {
        const time = new Date(item.timestamp).toLocaleString();
        html += `
            <div class="history-item" onclick="fillSearchForm('${item.artist}', '${item.song}')">
                <strong>${item.artist}</strong> - ${item.song}<br>
                <span class="time">${time}</span>
            </div>
        `;
    });
    
    historyList.innerHTML = html;
}

// Fill search form from history
function fillSearchForm(artist, song) {
    artistInput.value = artist;
    songInput.value = song;
    
    // Scroll to search form
    artistInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
    artistInput.focus();
}

// Setup example songs click handlers
function setupExampleSongs() {
    const exampleItems = document.querySelectorAll('.example-songs li');
    exampleItems.forEach((item, index) => {
        item.addEventListener('click', () => {
            const example = exampleSongs[index];
            if (example) {
                artistInput.value = example.artist;
                songInput.value = example.song;
                
                // Auto-search
                searchAndGenerate(example.artist, example.song);
            }
        });
    });
}

// Show loading state
function showLoading(show) {
    loading.style.display = show ? 'block' : 'none';
    searchBtn.disabled = show;
}

// Show error message
function showError(message) {
    // Create error notification
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-notification';
    errorDiv.innerHTML = `
        <i class="fas fa-exclamation-circle"></i>
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">&times;</button>
    `;
    
    // Style
    errorDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: var(--danger-color);
        color: white;
        padding: 15px 20px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        gap: 10px;
        z-index: 1000;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        animation: slideIn 0.3s ease;
    `;
    
    // Add to page
    document.body.appendChild(errorDiv);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (errorDiv.parentElement) {
            errorDiv.remove();
        }
    }, 5000);
}

// Show success notification
function showNotification(message) {
    // Create notification
    const notifyDiv = document.createElement('div');
    notifyDiv.className = 'success-notification';
    notifyDiv.innerHTML = `
        <i class="fas fa-check-circle"></i>
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">&times;</button>
    `;
    
    // Style
    notifyDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: var(--success-color);
        color: white;
        padding: 15px 20px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        gap: 10px;
        z-index: 1000;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        animation: slideIn 0.3s ease;
    `;
    
    // Add to page
    document.body.appendChild(notifyDiv);
    
    // Auto-remove after 3 seconds
    setTimeout(() => {
        if (notifyDiv.parentElement) {
            notifyDiv.remove();
        }
    }, 3000);
}

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Ctrl/Cmd + Enter to search
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        searchBtn.click();
    }
    
    // Escape to close modal
    if (e.key === 'Escape' && fullscreenModal.style.display === 'flex') {
        fullscreenModal.style.display = 'none';
    }
});

// Add CSS for notifications
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    .error-notification button,
    .success-notification button {
        background: none;
        border: none;
        color: white;
        font-size: 1.2rem;
        cursor: pointer;
        padding: 0;
        margin-left: 10px;
    }
`;
document.head.appendChild(style);

// Initialize with a default search
window.onload = () => {
    // Auto-search for a popular song on page load
    setTimeout(() => {
        if (artistInput.value && songInput.value) {
            searchAndGenerate(artistInput.value, songInput.value);
        }
    }, 1000);
};