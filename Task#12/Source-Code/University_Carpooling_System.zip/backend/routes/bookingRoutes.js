
const router = require('express').Router();
const Booking = require('../models/Booking');
const Ride = require('../models/Ride');

router.post('/book', async (req,res)=>{
  await new Booking(req.body).save();
  await Ride.findByIdAndUpdate(req.body.rideId, {$inc:{seats:-1}});
  res.send('Booked');
});

module.exports = router;
