
const router = require('express').Router();
const Ride = require('../models/Ride');

router.post('/create', async (req,res)=>{
  res.json(await new Ride(req.body).save());
});

router.get('/search', async (req,res)=>{
  res.json(await Ride.find({ seats: { $gt: 0 }}));
});

module.exports = router;
