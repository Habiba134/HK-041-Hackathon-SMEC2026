
const mongoose = require('mongoose');
module.exports = mongoose.model('Booking', new mongoose.Schema({
  rideId: String,
  passenger: String
}));
