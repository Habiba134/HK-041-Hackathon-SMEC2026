
const mongoose = require('mongoose');
module.exports = mongoose.model('Ride', new mongoose.Schema({
  driver: String,
  from: String,
  to: String,
  time: String,
  seats: Number
}));
