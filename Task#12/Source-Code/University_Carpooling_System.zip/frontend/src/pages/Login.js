
export default function Login(){
  return <h2>University Carpooling System</h2>
}
