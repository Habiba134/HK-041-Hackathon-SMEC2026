from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_mysqldb import MySQL
from config import Config
from models import init_db, mysql
from utils import init_mail, send_notification

app = Flask(__name__)
app.config.from_object(Config)

init_db(app)
init_mail(app)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO users(username,email,password) VALUES(%s,%s,%s)", (username,email,password))
        mysql.connection.commit()
        cur.close()
        flash('Registration successful!')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE email=%s AND password=%s", (email,password))
        user = cur.fetchone()
        cur.close()
        if user:
            session['user_id'] = user[0]
            session['role'] = user[4]
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid Credentials")
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM resources")
    resources = cur.fetchall()
    cur.close()
    return render_template('dashboard.html', resources=resources)

@app.route('/book/<int:resource_id>', methods=['GET','POST'])
def book(resource_id):
    if request.method == 'POST':
        date = request.form['date']
        slot = request.form['slot']
        user_id = session['user_id']
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM bookings WHERE resource_id=%s AND date=%s AND slot=%s AND status='approved'", (resource_id,date,slot))
        existing = cur.fetchone()
        if existing:
            flash("Slot already booked")
        else:
            cur.execute("INSERT INTO bookings(user_id,resource_id,date,slot) VALUES(%s,%s,%s,%s)", (user_id,resource_id,date,slot))
            mysql.connection.commit()
            flash("Booking Requested Successfully")
        cur.close()
        return redirect(url_for('dashboard'))
    return render_template('booking.html', resource_id=resource_id)

@app.route('/admin')
def admin_dashboard():
    if session.get('role') != 'admin':
        return redirect(url_for('login'))
    cur = mysql.connection.cursor()
    cur.execute("SELECT b.id, u.username, r.name, b.date, b.slot, b.status, u.email FROM bookings b JOIN users u ON b.user_id=u.id JOIN resources r ON b.resource_id=r.id")
    bookings = cur.fetchall()
    cur.close()
    return render_template('admin_dashboard.html', bookings=bookings)

@app.route('/admin/update/<int:booking_id>/<action>')
def update_booking(booking_id, action):
    if session.get('role') != 'admin':
        return redirect(url_for('login'))
    cur = mysql.connection.cursor()
    cur.execute("UPDATE bookings SET status=%s WHERE id=%s", (action, booking_id))
    mysql.connection.commit()
    cur.execute("SELECT u.email, r.name, b.date, b.slot FROM bookings b JOIN users u ON b.user_id=u.id JOIN resources r ON b.resource_id=r.id WHERE b.id=%s", (booking_id,))
    booking = cur.fetchone()
    cur.close()
    message = f"Your booking for {booking[1]} on {booking[2]} slot {booking[3]} is {action}"
    send_notification(booking[0], "Booking Status Update", message, app)
    return redirect(url_for('admin_dashboard'))

if __name__ == "__main__":
    app.secret_key = Config.SECRET_KEY
    app.run(debug=True)