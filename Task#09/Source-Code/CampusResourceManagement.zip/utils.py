from flask_mail import Message, Mail
from config import Config
mail = Mail()
def init_mail(app):
    mail.init_app(app)
def send_notification(email, subject, message, app):
    with app.app_context():
        msg = Message(subject, sender=Config.MAIL_USERNAME, recipients=[email])
        msg.body = message
        mail.send(msg)