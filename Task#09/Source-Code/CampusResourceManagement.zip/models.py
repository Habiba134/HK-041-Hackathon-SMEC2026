from flask_mysqldb import MySQL
mysql = MySQL()
def init_db(app):
    mysql.init_app(app)
    cur = mysql.connection.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS users(
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50),
        email VARCHAR(100),
        password VARCHAR(100),
        role ENUM('admin','user') DEFAULT 'user')""")
    cur.execute("""CREATE TABLE IF NOT EXISTS resources(
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100),
        type VARCHAR(50),
        description TEXT)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS bookings(
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        resource_id INT,
        date DATE,
        slot VARCHAR(20),
        status ENUM('pending','approved','declined') DEFAULT 'pending',
        FOREIGN KEY(user_id) REFERENCES users(id),
        FOREIGN KEY(resource_id) REFERENCES resources(id))""")
    mysql.connection.commit()
    cur.close()